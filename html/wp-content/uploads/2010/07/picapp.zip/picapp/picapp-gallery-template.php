<?php 

/*
Template Name: Picapp Gallery Template
*/

/*
 * This is a sample template file.  Copy this file to your WordPress theme's directory, and its markup will be used to display individual photos from the PicApp gallery.  
 * [picappgallerysingle] Is the placeholder that WordPress will replace with the PicApp-generated single gallery image.
 *
 */
 
?>
 
<p>Some custom text before the gallery image.</p>

[picappgallerysingle]
 
<p>More custom text, after the gallery image.</p>
